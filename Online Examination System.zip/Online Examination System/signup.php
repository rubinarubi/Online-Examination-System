
<?php 
include 'connection.php';

if(isset($_POST['submit'])) {
/*	if(isset($_POST['firstname'])){
		if(!empty($_POST['firstname'])){
			
		}else{$errMsg="Field Must not be Empty";}
	}
*/	
	$fname    = trim($_POST['firstname']);
	$lname    = trim($_POST['lastname']);
	$uname    = trim($_POST['username']);
	$upass    = trim($_POST['password']);
	$contact  = trim($_POST['contact']);
	$email    = trim($_POST['email']);
	$address  = trim($_POST['address']);
	
	
	
	$fname = strip_tags($fname);
	$lname = strip_tags($lname);
	$uname = strip_tags($uname);
	$upass = strip_tags($upass);
	$contact = strip_tags($contact);
	$email = strip_tags($email);
	$address = strip_tags($address);
	
	// password encrypt using SHA256();
	$password = hash('sha256', $upass);
	$cnfpassword = hash('sha256', $cnfpass);
	
	// check email exist or not
	$query = "SELECT email FROM signup WHERE email='$email'";
	$result = mysql_query($query);
	$count = mysql_num_rows($result); // if email not found then proceed
	if ($count==0) {
		
		$query = "INSERT INTO signup (first_name,last_name,username,password,confirm_password,contact,email,address) VALUES('$fname','$lname','$uname','$upass','$cnfpass','$contact','$email','$address')";
		$res = mysql_query($query);
		
		if ($res) {
			$errTyp = "success";
			$errMSG ="successfully registered, you may <a href=index.php>login</a> now";
			echo $errMSG;
		} else {
			$errTyp = "danger";
			$errMSG = "Something went wrong, try again later...";
			echo $errMSG;
		}	
		
	} else {
		$errTyp = "warning";
		$errMSG = "Sorry Email already in use ...";
		echo $errMSG;
	}
	
}
?>



<?php include 'include/header.php';?>
<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a  href="index.php">Home</a></li>
			<li><a href="about.php">About</a></li>
			<li><a id="active" href="signup.php">Sign Up</a></li>
			<li><a href="contact.php">Contact</a></li>
		</ul>
	</div>
	<div class="bodycontant clearfix">
		<div class="loginsection">
			<form name="" method="post" action="">
				<table>


					<h3>Registration Here</h3>
					<p class="msg">
						<?php echo "<span style=color:#ff0;>".$errMSG."</span>"; ?>
					</p>
					<tr>
						<td>First Name:</td>
						<td><input type="text" name="firstname" placeholder="Enter First Name" required/>
						</td>
					</tr>
					<tr>
						<td>Last Name:</td>
						<td><input type="text" name="lastname" placeholder="Enter Last Name" required/>
						</td>
					</tr>
					<tr>
						<td>UserName:</td>
						<td><input type="text" name="username" placeholder="Enter User Name" required/>
						</td>
					</tr>
					<tr>
						<td>Password:</td>
						<td><input type="password" name="password" placeholder="Enter Password" required/>
						</td>
					</tr>

					<tr>
						<td>Contact:</td>
						<td><input type="text" name="contact" placeholder="Enter  Contact" required/>
						</td>
					</tr>

					<tr>

						<td>Email Address:</td>
						<td><input type="email" name="email" placeholder="Enter Email Address" required/>
						</td>
					</tr>
					<tr>
						<td>Address:</td>
						<td>
							<textarea name="address"></textarea>
						</td>
					</tr>
					<tr>
						<td></td>
						<td>
							<input type="submit" name="submit" value="Submit"/>
							<input type="reset" name="reset" value="Reset"/>
						</td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</section>
		
<?php include 'include/footer.php';?>
