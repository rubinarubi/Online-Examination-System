



<?php include 'auth.php';?>
<?php include 'include/header.php';?>



<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
			<li><a id="active" href="about.php">About</a></li>
			<li><a href="signup.php">Sign Up</a></li>
			<li><a href="contact.php">Contact</a></li>
			
		</ul>
		<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
	</div>
	<div class="bodycontant">
	<div class="quizsection" style = "margin-bottom:88px">
	<?php
	
		if(isset($_REQUEST['submit']))
		{
		$sub_id=$_REQUEST['sub_id'];
		$re_id=$_REQUEST['result_id'];
		$user_id=$_SESSION['user_id'];
		$con_id=$_REQUEST['contest_id'];
		$ss="select * from question where sub_id='$sub_id' order by q_id asc ";
		$rr=mysql_query($ss);
		$c=0;
		$check=0;
		$total=0;
		while($arr=mysql_fetch_array($rr))
		{
		$total++;
			$c++;
			$aa='q'.$c;
//echo $aa."svfb";
			if($arr['true_ans']==$_REQUEST[$aa])
				$check++;
		$ans=$_REQUEST[$aa];
		$sql="select * from result where contest_id='$con_id' ";
		$rrr=mysql_query($sql);
		$aaaa=mysql_num_rows($rrr);
		if($aaaa==0)
		{
			$sss="insert into result(user_id,sub_id,q_id,ans,contest_id) values
					('$user_id','$sub_id','$arr[q_id]','$ans','$con_id') ";
					mysql_query($sss);
					}
		}
	//	echo "Accepted".$check;
	?>
	<h2> Total Accepted = <?php echo $check; ?> </h2>
	<h2> Score = <?php echo (($check/$total)*100)."%"; ?></h2> 
	
	<h2> Description: </h2>
	
	<?php				$c=0;
				$sql="select * from question where sub_id='$_REQUEST[sub_id]' order by q_id asc ";
				$res=mysql_query($sql);
				while($arr=mysql_fetch_array($res))
				{
					$c++;
			$aa='q'.$c;

	?>
	
	
				<p class="question"><?php echo $c; echo ". "; echo $arr['ques_des']; ?></p>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <font color="green">Correct Answer: <?php echo $arr['true_ans']; ?></font></br>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <font color="red">Your Answer: <?php echo $_REQUEST[$aa]; ?></font>
				
	
	<?php } } ?>
</section>

<?php   include 'include/footer.php';
