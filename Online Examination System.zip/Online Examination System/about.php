
<?//php include 'auth.php';?>
<?php include 'include/header.php';?>





<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a id="active" href="about.php">About</a></li>
			<li><a href="signup.php">Sign Up</a></li>
			<li><a href="contact.php">Contact</a></li>
			
		</ul>
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px";>
		<h2 class = "about" style= "width:364px"; > Online Examination System(OES)</h2>
		<p>Online Examination System(OES) is a Multiple Choice Questions(MCQ) based examination system that provides an easy to use environment for
		both Test Conducters and Students appearing for Examination. The main objective of OES is to provide all the features that an Examination 
		System must have, with the "interfaces that doesn't Scare it's Users!".</p>
		<h2>Taxonomy of OES</h2>
		<p>Users of OES are classified into Two categories: Administrators and Students. Administrators are responsible for 
		management of system users, subjects, tests, questions, results, system backup and recovery , etc. 
	    Students are the candidates appearing for the Examination.</p>
		<h2 style = "width:350px";>Features provided in Latest Release are:</h2>
		<p>» Supports Management of Users, Subjects, Tests, Questions and Results.</p>
        <p>» Fully Automated Evaluation and Results Calculation.</p>
		<p>» Provides test summary, results summary to both student and test conductor.</p>
		<h2>Next Release Objectives:</h2>
		<p>» To Provide Searching options, in each of the management sections.</p>
        <p>» To Provide WYSIWYG( What You See Is What You Get) editor, to make preparation of questions easier.</p>
		<p>» To make Online Examination System all browser compatible, to give best experience to its users with different browsers.</p>
		</section>
	
<?php include 'include/footer.php';?>
