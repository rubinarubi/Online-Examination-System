-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2016 at 05:35 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quiz_final`
--

-- --------------------------------------------------------

--
-- Table structure for table `contest`
--

CREATE TABLE IF NOT EXISTS `contest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `contest`
--

INSERT INTO `contest` (`id`, `sub_id`, `user_id`, `date`) VALUES
(22, 2, 20, '20-08-16');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user_type`, `username`, `password`) VALUES
(1, 'admin', 'admin', 'admin');


-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `q_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_id` int(11) DEFAULT NULL,
  `ques_des` varchar(255) DEFAULT NULL,
  `ans_1` varchar(100) DEFAULT NULL,
  `ans_2` varchar(100) DEFAULT NULL,
  `ans_3` varchar(100) DEFAULT NULL,
  `ans_4` varchar(100) DEFAULT NULL,
  `true_ans` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`q_id`),
  KEY `fk_Perquestion` (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`q_id`, `sub_id`, `ques_des`, `ans_1`, `ans_2`, `ans_3`, `ans_4`, `true_ans`) VALUES
(6, 2, 'What does CSS stand for?', 'Cascading Style Sheets', ' Colorful Style Sheets', 'Creative Style Sheets', 'Computer Style Sheets', 'Cascading Style Sheets'),
(7, 2, ' Which HTML attribute is used to define inline styles?', 'style', 'class', ' styles', ' font', 'style'),
(8, 2, 'Which property is used to change the background color?', 'color', 'bgcolor', 'background-color', 'bg-color', 'background-color'),
(9, 2, 'Which CSS property is used to change the text color of an element?', 'text-color', 'color', ' fgcolor', 'bgcolor', 'color'),
(10, 2, ' Which CSS property controls the text size?', 'font-style', 'text-size', ' text-style', 'font-size', 'font-size'),
(11, 2, ' How do you make each word in a text start with a capital letter?', 'You can''t do that with CSS', 'text-transform:capitalize', 'text-transform:uppercase', 'text-transform:normal', 'text-transform:uppercase'),
(12, 2, 'Which property is used to change the font of an element?', ' font', 'Both font-family and font can be used', 'font-family', 'font-size', 'font-family'),
(13, 2, ' How do you make the text bold?', 'font:bold;', 'style:bold;', 'font-weight:bold;', 'font-style:bold;', 'font-weight:bold;'),
(15, 5, 'What does PHP stand for?', 'PHP: Hypertext Preprocessor', 'Private Home Page', 'Personal Home Page', ' Personal Hypertext Processor', 'PHP: Hypertext Preprocessor'),
(16, 5, 'How do you write "Hello World" in PHP', 'echo "Hello World";', '"Hello World";', ' Document.Write("Hello World");', '''Hello World'';', 'echo "Hello World";'),
(17, 5, 'The PHP syntax is most similar to:  ', 'VBScript', ' Perl and C', 'JavaScript', 'HTML', ' Perl and C'),
(18, 5, 'What is the correct way to create a function in PHP?', ' create myFunction()', ' new_function myFunction() ', ' function myFunction() ', 'myFunction() ', ' function myFunction() '),
(19, 1, ' What is the previous version of HTML, prior to HTML5?', ' HTML 4', ' HTML 4.1', 'HTML 4.01', ' HTML 4.9 ', ' HTML 4'),
(20, 1, ' In HTML5, onblur and onfocus are:', 'Event attributes', ' HTML elements', 'Style attributes', 'CSS attributes', 'Event attributes'),
(21, 1, 'In HTML5, which method is used to get the current location of a user?', 'getUserPosition()', ' getPosition() ', ' getCurrentPosition() ', ' getControlPosition() ', ' getCurrentPosition() '),
(22, 1, 'The new HTML5 global attribute, "contenteditable" is used to:', 'Return the position of the first found occurrence of content inside a string', 'Update content from the server', 'Specifies a context menu for an element. The menu appears when a user right-clicks on the element', ' Specify whether the content of an element should be editable or not', ' Specify whether the content of an element should be editable or not'),
(23, 1, ' In HTML5, contextmenu and spellcheck are:', ' HTML attributes', 'Event attributes', 'Style attributes', 'HTML elements', ' HTML attributes'),
(24, 1, 'Graphics defined by SVG is in which format?', 'CSS', ' XML ', 'HTML', 'PHP', ' XML '),
(25, 1, ' Which built-in HTML5 object is used to draw on the canvas?', 'getContent', ' getCanvas ', 'getContext', 'getGraphics', 'getGraphics'),
(26, 1, ' In HTML5, which attribute is used to specify that an input field must be filled out?', 'formvalidate', 'validate', 'placeholder', ' required ', ' required '),
(27, 1, 'Which input type defines a slider control?', 'range', 'controls', 'slider', ' search ', 'range'),
(28, 1, 'Which input type defines a week and year control (no time zone)?', ' year ', 'date', 'week', 'month', 'week'),
(29, 2, ' How do you display a border like this: The top border = 10 pixels The bottom border = 5 pixels The left border = 20 pixels The right border = 1pixel?', ' border-width:10px 5px 20px 1px; ', ' border-width:10px 1px 5px 20px; ', ' border-width:10px 20px 5px 1px; ', ' border-width:5px 20px 10px 1px; ', ' border-width:10px 1px 5px 20px; '),
(30, 2, 'Which property is used to change the left margin of an element?', ' margin-left', 'padding-left', ' indent', ' margin-top', ' margin-left'),
(31, 5, ' All variables in PHP start with which symbol?', ' & ', ' $ ', '!', '=!', ' $ '),
(32, 5, 'How do you get information from a form that is submitted using the "get" method?', ' Request.Form; ', ' $_GET[]; ', ' Request.QueryString; ', ' Request.From; ', ' $_GET[]; '),
(33, 5, ' In PHP you can use both single quotes ( '' '' ) and double quotes ( " " ) for strings:', 'True', 'False', 'True or False', 'No statement', 'True'),
(35, 5, 'What is the correct way to open the file "time.txt" as readable?', ' fopen("time.txt","r+"); ', ' open("time.txt"); ', ' open("time.txt","read"); ', ' fopen("time.txt","r"); ', ' fopen("time.txt","r"); '),
(36, 5, ' Which superglobal variable holds information about headers, paths, and script locations?', ' $_SERVER ', ' $_GET ', ' $_SESSION ', ' $_GLOBALS ', ' $_SERVER '),
(37, 5, 'What is the correct way to add 1 to the $count variable?', ' count++; ', ' $count =+1 ', ' $count++; ', ' ++count ', ' $count++; '),
(38, 4, 'What does HTML stand for?', 'Hyperlinks and Text Markup Language', ' Hyper Text Markup Language ', 'Home Tool Markup Language', 'Home Tool Makeup Language', ' Hyper Text Markup Language '),
(39, 4, 'Who is making the Web standards?', ' The World Wide Web Consortium ', ' Google ', 'Microsoft', ' Mozilla ', ' The World Wide Web Consortium '),
(40, 4, 'Inline elements are normally displayed without starting a new line.  ', ' False ', 'True or  False ', 'True', 'No statement', 'True'),
(41, 4, 'Which HTML attribute specifies an alternate text for an image, if the image cannot be displayed?', 'alt', 'src', 'title', ' longdesc ', 'alt'),
(42, 6, ' How do you write "Hello World" in an alert box?', ' msg("Hello World"); ', ' msgBox("Hello World"); ', ' alert("Hello World"); ', ' alertBox("Hello World"); ', ' alert("Hello World"); '),
(43, 6, 'How do you create a function in JavaScript?  ', ' function myFunction() ', ' function:myFunction() ', ' function = myFunction() ', ' function == myFunction() ', ' function myFunction() '),
(44, 6, 'How do you call a function named ', ' myFunction() ', ' call function myFunction() ', ' call myFunction() ', ' myFunction call () ', ' myFunction() '),
(45, 6, 'How to write an IF statement in JavaScript?', ' if (i == 5) ', ' if i = 5 then ', ' if i = 5 ', ' if i == 5 then ', ' if (i == 5) '),
(46, 6, 'What is the correct way to write a JavaScript array?', ' var colors = 1 = (', ' var colors = ', ' var colors = [', ' var colors = (1:', ' var colors = ['),
(47, 6, ' How do you round the number 7.25, to the nearest integer?  ', ' round(7.25) ', ' Math.rnd(7.25) ', ' rnd(7.25) ', ' Math.round(7.25) ', ' Math.round(7.25) '),
(48, 6, ' How do you find the number with the highest value of x and y?  ', ' Math.max(x, y) ', ' ceil(x, y) ', ' top(x, y) ', ' Math.ceil(x, y) ', ' Math.ceil(x, y) '),
(49, 6, 'How can you detect the client''s browser name?  ', ' browser.name ', ' navigator.appName ', ' client.navName ', 'navName ', ' browser.name '),
(50, 6, ' Which event occurs when the user clicks on an HTML element?  ', 'onmouseclick', ' onchange ', 'onmouseover', 'onclick', 'onclick'),
(51, 6, 'How do you declare a JavaScript variable?', ' v carName; ', ' var carName; ', ' variable carName; ', 'carName; ', ' var carName; ');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE IF NOT EXISTS `result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `contest_id` int(11) NOT NULL,
  `ans` varchar(255) NOT NULL,
  `sub_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `q_id`, `user_id`, `contest_id`, `ans`, `sub_id`) VALUES
(11, 42, 20, 6, ' alert(', 6),
(12, 43, 20, 6, ' function myFunction() ', 6),
(13, 44, 20, 6, ' myFunction() ', 6),
(14, 45, 20, 6, ' if (i == 5) ', 6),
(15, 46, 20, 6, ' var colors = [', 6),
(16, 47, 20, 6, ' round(7.25) ', 6),
(17, 48, 20, 6, ' top(x, y) ', 6),
(18, 49, 20, 6, ' client.navName ', 6),
(19, 50, 20, 6, 'onmouseclick', 6),
(20, 51, 20, 6, ' var carName; ', 6),
(31, 6, 20, 7, 'Cascading Style Sheets', 2),
(32, 19, 20, 8, '', 1),
(33, 42, 20, 10, '', 6),
(34, 38, 20, 11, '', 4),
(35, 19, 20, 12, ' HTML 4.1', 1),
(36, 15, 20, 15, 'Personal Home Page', 5),
(37, 42, 20, 16, '', 6),
(38, 6, 20, 17, '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `confirm_password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `first_name`, `last_name`, `username`, `password`, `confirm_password`, `contact`, `email`, `address`) VALUES
(19, 'rubina', 'rubi', 'rubii', 'rubi', 'rubi', '014654', 'rubina@gmail.com', 'gfggryg'),
(20, 'rr', 'rr', 'rr', 'rr', 'rr', '1323435', 'erer@gmail.com', 'fweff'),
(21, 'pp', 'pp', 'pp', 'pp', '', '57687989', 'pp@gmail.com', 'dgfh'),
(22, 'fh', 'hgh', 'gfhh', 'ghh', '', '6879809', 'pho@mail', ''),
(23, 'pp', 'ftjyk', 'jghyk', 'kgk', '', '687980', 'dret@yahoo', ''),
(24, 'u888', '8i', 'uiio', 'u', '', 'yukiu', 'fjy@gmail.com', 'fggj'),
(25, 'axsc', 'dvf', 'ffb', 'bgb', '', '76679', 'egt@gmail.com', 'wtery'),
(26, '7987', '7i8i', 'erhru', '7iyog', '', '56799', 'sdfdg@gmail.com', 'sffeht'),
(27, '6u6i', 'dhrj', 'fjgk', 'setey', '', '567879', 'ferh@gmail', 'sgrttj'),
(28, 'oio', 'kuiliiiiiiiiiiiiiiiiiiiiii', 'kui', 'kgui', '', '8890', 'ghk@gmail.com', 'jyk'),
(29, 'eryru', 'ytujy', 'jktyu', 'sth', '', '46576879', 'yty@gmail.com', 'aeteytj'),
(30, 'asfs', 'dgfggth', 'fgghhtf', 'fthfj', '', 'fhtf', 'dreafrgdgtt@yahoo', 'affdrgd');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `sub_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(80) NOT NULL,
  `total_question` varchar(100) NOT NULL,
  PRIMARY KEY (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `sub_name`, `total_question`) VALUES
(1, 'HTML 5', '10'),
(2, 'CSS', '10'),
(4, 'HTML', '10'),
(5, 'PHP', '10'),
(6, 'JAVA SCRIPT', '10');



--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `fk_Perquestion` FOREIGN KEY (`sub_id`) REFERENCES `subject` (`sub_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
