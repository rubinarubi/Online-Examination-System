<?php include 'auth.php';?>
<?php include 'connection.php';
 include 'include/header.php';



if(isset($_REQUEST['submit']))
{
	$date=date("d-");
	$month=date("m-");
	$year=date("y");
	$d_c=$date.$month.$year;
	
	$ss="select * from contest where sub_id='$_REQUEST[sub_id]' and user_id='$_SESSION[user_id]' and date='$d_c' ";
	$res=mysql_query($ss);
	$row=mysql_num_rows($res);
	if($row>=1)
	{
		?>
		<script>
			 alert("You already performed today.... try again another day!!!");
			setTimeout(window.close(),0000);
			
			
		</script>
		<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="category.php">Home</a></li>
			<li><a href="about.php">About</a></li>
			<li><a href="signup.php">Sign Up</a></li>
			<li><a href="contact.php">Contact</a></li>
		</ul>
				<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
			</div>
		</div>
		
	</div>
	<div class="bodycontant clearfix">
	
	<!--<div class="quizsection" style="width:700px;height:450px;padding:10px;overflow-y:scroll;margin-bottom:20px;">-->
		
		<?php
		
		
		
		
	}
	else{
	
	
	//echo $date;
	$sql="insert into contest (sub_id,user_id,date)
			values ('$_REQUEST[sub_id]','$_SESSION[user_id]','$d_c')";
					mysql_query($sql);
	$ss="select * from contest order by id desc ";
	$rr=mysql_query($ss);
	$kk=mysql_fetch_array($rr);
//echo $kk['id'];

?>
</section>
<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
			<li><a href="about.php">About</a></li>
			<li><a href="signup.php">Sign Up</a></li>
			<li><a href="contact.php">Contact</a></li>
		</ul>
		
				<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
		
		
	</div>
	<div class="bodycontant clearfix">
		
		
		</br>
		

		<div class="quizsection" style="width:700px;height:450px;padding:10px;overflow-y:scroll;margin-bottom:20px;margin-left:40px">

		<?php 
			
		
		
		
				$c=0;
				$sql="select * from question where sub_id='$_REQUEST[sub_id]' order by q_id asc ";
				$res=mysql_query($sql);
				while($arr=mysql_fetch_array($res))
				{
					$c++;
		
		
		?>

			<form name ="" method="post" action="result.php" style = "margin-left:106px";>

		
			<p class="question"><?php echo $c; echo ". "; echo $arr['ques_des']; ?></p>
				<ul class="answers">
				<input type="radio" name="<?php echo 'q'.$c;?>" value="<?php echo $arr['ans_1']; ?>" id="q1a"><label for="q1a"><?php echo $arr['ans_1']; ?></label><br/>
				
				<input type="radio" name="<?php echo 'q'.$c;?>" value="<?php echo $arr['ans_2']; ?>" id="q1b"><label for="q1b"><?php echo $arr['ans_2']; ?></label><br/>
				<input type="radio" name="<?php echo 'q'.$c;?>" value="<?php echo $arr['ans_3']; ?>" id="q1c"><label for="q1c"><?php echo $arr['ans_3']; ?></label><br/>
				<input type="radio" name="<?php echo 'q'.$c;?>" value="<?php echo $arr['ans_4']; ?>" id="q1d"><label for="q1d"><?php echo $arr['ans_4']; ?></label><br/>
				</ul> 
				
		<?php   } }?>
			<input type="hidden" name="sub_id" value="<?php echo $_REQUEST[sub_id]; ?>">
			<input type="hidden" name="contest_id" value="<?php echo $kk['id']; ?>">
			<input class = "ct_submit" type="submit" name="submit" value="Submit">
			

		</form>
		</div>
		
		<div></div>
	
	</div>
</section>
		
<?php   include 'include/footer.php';

}
else
{

header("location:home.php");

}
?>
