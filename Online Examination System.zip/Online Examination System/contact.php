
<?php//include 'auth.php';?>
<?php include 'include/header.php';?>





<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a href="about.php">About</a></li>
			<li><a href="signup.php">Sign Up</a></li>
			<li><a id="active" href="contact.php">Contact</a></li>
			
		</ul>
		
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px";>
		<div class="contact1" style="color:blue;font-size:20px";>
		<h1 style= "">For help with Online Examination System</h1>
		<div class="contact"style="color:white";>
		E-mail : onlinequizooo2@gmail.com<br/>Cell : +00 01722222222<br/> &nbsp &nbsp &nbsp +00 01558796574<br/> 
		 &nbsp &nbsp &nbsp +88 0821332211
		</div>
		</div>
			</section>
	
<?php include 'include/footer.php';?>
