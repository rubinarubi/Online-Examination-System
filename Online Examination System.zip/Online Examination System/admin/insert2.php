
<?php include 'auth.php';?>
<?php include 'include/header.php';?>

<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
		</ul>
		<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px";>
		
			
			</form></div>
		<div></div>
	</div>
</section>

<table align="center" cellpadding="0" bgcolor="#FFFFFF" width="800" border="0">
  <tr>
    <td><h1 align="center" class="heading">Welcome to Admin Panel</h1>
  <p align="center">
        <?php 
			//if(isset($_REQUEST['submit'])){
			 //$id=$REQUEST['id'];
			 $des=$_REQUEST['name']; 
			 
			 $an_1=$_REQUEST['ans_1'];
			 $an_2=$_REQUEST['ans_2'];
			 $an_3=$_REQUEST['ans_3'];
			 $an_4=$_REQUEST['ans_4'];
			 $true_an=$_REQUEST['true_ans'];
	 
			 $link=mysql_connect("localhost","root","") or die("Cannot Connect to the database!");
			
			 mysql_select_db("quiz_final",$link) or die ("Cannot select the database!");
			 
			
			
			//$query = "SELECT sub_id FROM subject WHERE sub_id='$id'";
			$sub_id=$_REQUEST['sid'];
			echo $sub_id;
			//$query="INSERT INTO question (des, ans_1, ans_2, ans_3,ans_4,true_ans) values('".$des."', '".$an_1."', '".$an_2."', '".$an_3."''".$an_4."''".$true_an."')";
			$query="insert into question (sub_id,ques_des, ans_1, ans_2, ans_3,ans_4,true_ans) values ('$sub_id','$des','$an_1','$an_2','$an_3','$an_4','$true_an') ";
			
			
			
			if(!mysql_query($query,$link))
		  {
		  die ("An unexpected error occured while saving the record, Please try again!");
		  }
		  else
		 {
		  echo "New record saved successfully!";
		  }
			

	 ?>
      </p>
   </td>
  </tr>
</table>
					
		
<?php include 'include/footer.php';?>
