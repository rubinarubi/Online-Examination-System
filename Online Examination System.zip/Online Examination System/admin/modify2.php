
<?php include 'auth.php';?>
<?php include 'include/header.php';?>

<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
			
		</ul>
		<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px";>
		
			
			</form></div>
		<div></div>
	</div>


<table align="center" cellpadding="0" bgcolor="#FFFFFF" width="800" border="0">
  <tr>
    <td><h1 align="center" class="heading">Welcome to Admin Panel</h1>
  <p align="center">
    <?php 
	
	if(isset($_REQUEST['button']))
	{
		$id=$_REQUEST['id'];
	 $des=$_REQUEST['name']; 
	 $an_1=$_REQUEST['ans_1'];
	 $an_2=$_REQUEST['ans_2'];
	 $an_3=$_REQUEST['ans_3'];
	 $an_4=$_REQUEST['ans_4'];
	 $true_an=$_REQUEST['true_ans'];
	 
	 if($true_an!=$an_1 && $true_an!=$an_2 && $true_an!=$an_3 && $true_an!=$an_4)
		{
			echo "True answer not matched!!";
		}
	 else
	 {
	 $link=mysql_connect("localhost","root","") or die("Cannot Connect to the database!");
	
	 mysql_select_db("quiz_final",$link) or die ("Cannot select the database!");
	 $query="UPDATE question SET ques_des='".$des."', ans_1='".$an_1."', ans_2='".$an_2."', ans_3='".$an_3."', ans_4='".$an_4."', true_ans='".$true_an."' WHERE q_id='".$id."'";
		
		  if(!mysql_query($query,$link))
		  {die ("An unexpected error occured while saving the record, Please try again!");}
		  else
		 {
		  echo "Record updated successfully!";}
		  }

	}
	
	
	 $id=$_REQUEST['id']; 
	 
	 $link=mysql_connect("localhost","root","") or die("Cannot Connect to the database!");
	
	 mysql_select_db("quiz_final",$link) or die ("Cannot select the database!");
	 $query="SELECT * FROM question WHERE q_id='".$id."'";
		
		 $resource=mysql_query($query,$link) or die ("An unexpected error occured while <b>deleting</b> the record, Please try again!");
		  $result=mysql_fetch_array($resource);
		  
	 ?>
     <form id="form1" name="form1" method="get" action="modify2.php">
        <table align="center" width="291" border="0">
          <tr>
            <td width="129"><strong>Description:</strong></td>
            <td width="152">
            <input type="hidden" name="id" value="<?php echo $result[0] ?>"  />
            <label>
              <input name="name" type="text" id="textfield" value="<?php echo $result[2] ?>" />
            </label></td>
          </tr>
          <tr>
            <td><strong>Answer_1:</strong></td>
            <td><input name="ans_1" type="text" id="textfield2" value="<?php echo $result[3] ?>" /></td>
          </tr>
          <tr>
            <td><strong>Answer_2:</strong></td>
            <td><input type="text" name="ans_2" id="textfield3" value="<?php echo $result[4] ?>" /></td>
          </tr>
          <tr>
            <td><strong>Answer_3:</strong>:</td>
            <td><input type="text" name="ans_3" id="textfield4" value="<?php echo $result[5] ?>" /></td>
          </tr>
		            <tr>
            <td><strong>Answer_4:</strong>:</td>
            <td><input type="text" name="ans_4" id="textfield4" value="<?php echo $result[6] ?>" /></td>
          </tr>
		            <tr>
            <td><strong>True Answer:</strong>:</td>
            <td><input type="text" name="true_ans" id="textfield4" value="<?php echo $result[7] ?>" /></td>
          </tr>
        </table>
        <p align="center">
          <label>
            <input type="submit" name="button" id="button" value="Modify" />
          </label>
        </p>
        
      </form>

      </p>
      <p align="center"><a href="delete.php"><a href="../"></a></p>
      <p align="left">&nbsp;</p>
    <p align="left">&nbsp;</p></td>
  </tr>
</table>
					
</section>	
<?php include 'include/footer.php';?>
