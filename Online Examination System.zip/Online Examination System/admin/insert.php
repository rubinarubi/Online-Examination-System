
<?php include 'auth.php';?>
<?php include 'include/header.php';?>

<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
			
		</ul>
		<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px";>
		
			
			</form></div>
		<div></div>
	</div>
</section>

<table align="center" cellpadding="0" bgcolor="#FFFFFF" width="800" border="0">
  <tr>
    <td><h1 align="center" class="heading">Welcome to Admin Panel</h1>
  <p align="center">
<?php 
	//$sid=$_GET['sid'];
	//echo $sid;
	
	?>
     <form id="form1" name="form1" method="get" action="insert2.php">
        <table align="center" width="291" border="0">
          <tr>
            <td width="129"><strong>Description:</strong></td>
            <td width="152">
            <input type="hidden" name="sid" value="<?php echo $_REQUEST['sid']; ?>"  />
            <label>
              <input name="name" type="text" id="textfield" value="<?php echo $result[2] ?>" />
            </label></td>
          </tr>
          <tr>
            <td><strong>Answer_1:</strong></td>
            <td><input name="ans_1" type="text" id="textfield2" value="<?php echo $result[3] ?>" /></td>
          </tr>
          <tr>
            <td><strong>Answer_2:</strong></td>
            <td><input type="text" name="ans_2" id="textfield3" value="<?php echo $result[4] ?>" /></td>
          </tr>
          <tr>
            <td><strong>Answer_3:</strong>:</td>
            <td><input type="text" name="ans_3" id="textfield4" value="<?php echo $result[5] ?>" /></td>
          </tr>
		            <tr>
            <td><strong>Answer_4:</strong>:</td>
            <td><input type="text" name="ans_4" id="textfield4" value="<?php echo $result[6] ?>" /></td>
          </tr>
		            <tr>
            <td><strong>True Answer:</strong>:</td>
            <td><input type="text" name="true_ans" id="textfield4" value="<?php echo $result[7] ?>" /></td>
          </tr>
        </table>
        <p align="center">
          <label>
            <input type="submit" name="button" id="button" value="Insert" />
          </label>
        </p>
        
      </form>

      </p>
     </td>
  </tr>
</table>
					
		
<?php include 'include/footer.php';?>
