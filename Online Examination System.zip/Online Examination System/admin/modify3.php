
<?php include 'auth.php';?>
<?php include 'include/header.php';?>

<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
			
		</ul>
		<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px";>
		
			
			</form></div>
		<div></div>
	</div>
</section>

<table align="center" cellpadding="0" bgcolor="#FFFFFF" width="800" border="0">
  <tr>
    <td><h1 align="center" class="heading">Welcome to Admin Panel</h1>
  <p align="center">
    <?php 
	 $id=$_REQUEST['id'];
	 $des=$_REQUEST['name']; 
	 $an_1=$_REQUEST['ans_1'];
	 $an_2=$_REQUEST['ans_2'];
	 $an_3=$_REQUEST['ans_3'];
	 $an_4=$_REQUEST['ans_4'];
	 $true_an=$_REQUEST['true_ans'];
	 
	 if($true_an!=$an_1 && $true_an!=$an_2 && $true_an!=$an_3 && $true_an!=$an_4)
		{
			echo "True answer not matched!!";
		}
	 else
	 {
	 $link=mysql_connect("localhost","root","") or die("Cannot Connect to the database!");
	
	 mysql_select_db("quiz_final",$link) or die ("Cannot select the database!");
	 $query="UPDATE question SET ques_des='".$des."', ans_1='".$an_1."', ans_2='".$an_2."', ans_3='".$an_3."', ans_4='".$an_4."', true_ans='".$true_an."' WHERE q_id='".$id."'";
		
		  if(!mysql_query($query,$link))
		  {die ("An unexpected error occured while saving the record, Please try again!");}
		  else
		 {
		  echo "Record updated successfully!";}
		  }
	 ?>

      </p>
     
  </tr>
</table>		
		
<?php include 'include/footer.php';?>
