
<?php include 'auth.php';?>
<?php include 'include/header.php';?>





<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
			
		</ul>
		<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px;margin-top:80px";>
			
			<!--<h2>SELECT THE OPTION </h2>-->
			
		<table>
					<form action="modify.php" method="get">
					<tr>
						<td>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
						
					&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
					Select Quiz Category:</td>
						<td><select name="sub_id" <!--style = "margin-left:251px;"-->>
						<?php
					$sql = "select * from subject order by sub_name asc ";
					$res = mysql_query($sql);
					while($arr = mysql_fetch_array($res))
					{
						?>
						<option value="<?php echo $arr['sub_id']; ?>"><?php echo $arr['sub_name']; ?></option>
						<?php echo $arr['sub_name'];?></a></li>
					<?php } ?>
						</select>
						<td  style="margin-left:20px";><input type="submit" name="submit" value="Start"></td>

					<tr>
						<td></td>
					</tr>
				</form>
				</table>
			</form></div>
		<div></div>
	</div>
</section>
		
<?php include 'include/footer.php';?>
