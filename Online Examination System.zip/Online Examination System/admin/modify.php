
<?php include 'auth.php';?>
<?php include 'include/header.php';?>

<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
			
		</ul>
		<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px";>
		
			
			</form></div>
		<div></div>
	</div>

<table align="center" cellpadding="0" bgcolor="#FFFFFF" width="800" border="0">
  <tr>
  <?php 
	//$sid=$_REQUEST['sub_id'];
	//echo $sid;
	
	?>
    <td><h1 align="center" class="heading">Welcome to Admin Panel</h1>
	<h2><a href="insert.php?sid=<?php echo $_REQUEST['sub_id'];?>">Insert</a></h2>
  <p align="center">
	
 
    <?php 
	 	 $link=mysql_connect("localhost","root","") or die("Cannot Connect to the database!");
	
	 mysql_select_db("quiz_final",$link) or die ("Cannot select the database!");
	 if(isset($_REQUEST['submit'])){
	 $sql="select * from question where sub_id='$_REQUEST[sub_id]' order by q_id asc ";
	 //$query="SELECT * FROM question";
		
		  $resource=mysql_query($sql,$link);
		  echo "
			<table align=\"center\" border=\"1\" width=\"100%\" cellpadding=\"5px\" >
			<tr>
			<td><b>Description</b></td> <td><b>Ans_1</b></td><td><b>Ans_2</b></td><td><b>Ans_3</b></td><td><b>Ans_4</b></td><td><b>True Ans.</b></td><td><b>Action</b></td></tr> ";
	while($result=mysql_fetch_array($resource))
	{ 
	echo "<tr ><td>".$result[2]."</td><td>".$result[3]."</td><td>".$result[4]."</td><td>".$result[5]."</td><td>".$result[6]."</td><td>".$result[7]."</td><td>
	<a href=\"modify2.php?id=".$result[0]."\">Modify||</a><a href=\"delete.php?id=".$result[0]."\">Delete</a>
	</td></tr>";
	} echo "</table>";
}
	 ?>
	 
	 
						
      </p>
  
    </td>
  </tr>
</table>

</section>
					
		
<?php include 'include/footer.php';?>
