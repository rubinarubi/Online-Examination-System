<section class="footersection clearfix">
			<h3>Contact Us: +88 0821 232314</h3>
			
		</section>
		</div>

        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.12.0.min.js"><\/script>')</script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

    </body>
</html>

		
		