



<?php
	include 'connection.php';
	include 'include/header.php';

	session_start();
	?>
<?php //include 'include/header.php';?>

<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a href="home.php">Home</a></li>
			
		</ul>
	</div>
	<div class="bodycontant clearfix">
	<?php
	    // If form submitted, insert values into the database.
	 if (isset($_POST['submit'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
		//echo $username;
		//echo $password;
	//Checking is user existing in the database or not
        $query = "SELECT * FROM login WHERE username='$username' and password='$password'";
		$result = mysql_query($query) or die(mysql_error());
		$rows = mysql_num_rows($result);
		$arr=mysql_fetch_array($result);
		/*echo "welcome we meet the".$rows;*/
        if($rows==1){
			$_SESSION['username'] = $username;
			$_SESSION['user_id']=$arr['id'];
			header("Location:home.php"); // Redirect user to home.php
            }else{
				echo "<div class='form'><h3>Username/password is invalid.</h3><!--<br/>Click here to <a href='index.php'>Login</a>--></div>";
				}
    }
	?>
		<div class="loginsection">
			<form name ="" method="post" action="">
				<h3> Administrative Login Site</h3>
				<p class="msg">
					
					
				</p>
				<table>
				
					<tr>
						<td>User Name :</td>
						<td> <input type="text" name="username" placeholder="Enter User Name"></td>
					</tr>
					<tr>
						<td>Password :</td>
						<td><input type="password" name="password" placeholder="Enter Password"></td>
					</tr>
					
					<tr>
						<td></td>
						<td><input type="submit" name="submit" value="Submit"></td>
					</tr>
				
				</table>
			</form>
		</div>
	</div>
</section>
		
<?php include 'include/footer.php';?>
<?php  ?>