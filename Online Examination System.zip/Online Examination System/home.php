
<?php include 'auth.php';?>
<?php include 'include/header.php';?>





<section class="maincontant clearfix">
	<div class="navsection clearfix">
		<ul>
			<li><a id="active" href="home.php">Home</a></li>
			<li><a href="about.php">About</a></li>
			<li><a href="signup.php">Sign Up</a></li>
			<li><a href="contact.php">Contact</a></li>
			
		</ul>
		<div class="logoutsection clearfix">
			<ul>
				<li><span class="sessionname">Welcome <?php echo $_SESSION['username']; ?>!</span></li>
				<li><a href="logout.php">Logout</a></li>
			
			</ul>
		</div>
		
	</div>
	<div class="bodycontant clearfix">
		<div></div>
		<div class="quizsection" style = "margin-bottom:88px";>
			
			<h2>START THE QUIZ</h2>
			<h3>your online quize are in here, please press the start button</h3>
			<p>You can test your HTML,HTML5,PHP,CSS,JAVA SCRIPT skills with Online Quiz System.
			The test contains 10 questions and there is no time limit. 

			The test is not official, it's just a nice way to see how much you know, or don't know, about HTML,HTML5,PHP,CSS,JAVA SCRIPT .
			Count Your Score

			You will get 1 point for each correct answer. At the end of the Quiz, your total score will be displayed. Maximum score is 10 points.</p>
		<table>
					<form action="category.php" method="post">
					<tr>
						<td>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
						
					&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
					Quiz Category:</td>
						<td><select name="sub_id" <!--style = "margin-left:251px;"-->>
						<?php
					$sql = "select * from subject order by sub_name asc ";
					$res = mysql_query($sql);
					while($arr = mysql_fetch_array($res))
					{
						?>
						<option value="<?php echo $arr['sub_id']; ?>"><?php echo $arr['sub_name']; ?></option>
						<?php echo $arr['sub_name'];?></a></li>
					<?php } ?>
						</select>
						<td  style="margin-left:20px";><input type="submit" name="submit" value="Start"></td>

					<tr>
						<td></td>
					</tr>
				</form>
				</table>
			</form></div>
		<div></div>
	</div>
</section>
		
<?php include 'include/footer.php';?>
