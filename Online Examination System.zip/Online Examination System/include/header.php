<?php 
include "connection.php"; 

?>

<!doctype html>
<html>
    <head>
        <title>OQS</title>
       
        <!-- Place favicon.ico in the root directory -->

        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
       
		<div class="containar clearfix">
        <section class="headersection clearfix">
			<h1>Online Quiz System</h1>
			<p>Try to self-assesment</p>
		</section>